

public class Auto extends Policy{
	private String make;
	private String model;
	private double liability;
	private double collision;
	
	public void enterPolicyInfo(String firstName, String lastName, String make, String model, double liability, double collision) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.make = make;
		this.model = model;
		this.liability = liability;
		this.collision = collision;
		    }
	
	
	public double computeCommission() {
		return (liability + collision) * 0.30;  
		    }
	
	public void printPolicy() {
	System.out.printf("Auto Policy%n-----------%nName: %s %s%nMake: %s%nModel: %s%nLiability: $%,.2f%nCollision: $%,.2f%nCommission: $%,.2f%n%n",
			firstName, lastName, make, model, liability, collision, computeCommission());
		    }
		}

