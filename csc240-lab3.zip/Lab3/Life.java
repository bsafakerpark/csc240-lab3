


	public class Life extends Policy {
		
			private int age;
			private double term;
			
		public void enterPolicyInfo(String firstName, String lastName, int age, double term) {
			this.firstName = firstName;
			this.lastName = lastName;
			this.age = age;
			this.term = term;
			}

		public double computeCommission() {
			return term * 0.20;  
			    }

		public void printPolicy() {
			System.out.printf("Life Policy%n-----------%nName: %s %s%nAge: %d%nTerm: $%,.2f%nCommission: $%,.2f%n%n",
					firstName, lastName, age, term, computeCommission());
			    }
			}



